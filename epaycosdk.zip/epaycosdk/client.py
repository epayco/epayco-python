import urllib.request
import urllib.parse
import ssl
import json
import base64
import hashlib
import requests
import epaycosdk.errors as errors
from Crypto.Cipher import AES
import os
import sys
import traceback
from requests.exceptions import ConnectionError
from pathlib import Path
from requests import Session
import os
from dotenv import load_dotenv
import json
load_dotenv()


ssl._create_default_https_context = ssl._create_unverified_context

BS = 16
pad = lambda s: s + (BS - len(s) % BS) * chr(BS - len(s) % BS)
unpad = lambda s : s[0:-(s[-1])]

BASE_DIR = Path(__file__).resolve().parent.parent
EPAYCO_KEY_LANG_FILE = str(BASE_DIR.joinpath('epaycosdk/utils/key_lang.json'))
EPAYCO_KEY_LANG_FILE_APIFY = str(BASE_DIR.joinpath('epaycosdk/utils/key_lang_apify.json'))

class AESCipher:
    def __init__(self, key, iv):
        self.key = key
        self.iv = iv    

    def encrypt(self, row):
        raw = pad(row).encode("utf8")
        cipher = AES.new(self.key.encode("utf8"), AES.MODE_CBC, self.iv.encode("utf8"))
        enc = cipher.encrypt(raw)
        return base64.b64encode(enc)

    def encryptArray(self, data):
        aux = {}
        for key, value in data.items():
            if key == "extras_epayco" and isinstance(value, dict) and "extra5" in value:
                aux[key] = {"extra5": self.encrypt(value["extra5"]).decode('utf-8')}
            else:
                aux[key] = self.encrypt(value).decode('utf-8')
        return aux



class Util():

    def setKeys(self, array={},sp=''):
        file = open(EPAYCO_KEY_LANG_FILE, 'r').read()
        values = json.loads(file)
        aux = {}
        for key, value in array.items():
            if key in values:
                aux[values[key]] = value
            else:
                aux[key] = value
        return aux

    def setKeys_apify(self, array={}):
        file = open(EPAYCO_KEY_LANG_FILE_APIFY, 'r').read()
        values = json.loads(file)
        aux = {}
        for key, value in array.items():
            if key in values:
                aux[values[key]] = value
            else:
                aux[key] = value
        return aux


class Auth:
    def __init__( self, api_key, private_key ):
        self.api_key = api_key
        self.private_key = private_key

    def make(self, BASE_URL, BASE_URL_APIFY, apify):
        url = BASE_URL_APIFY + "/login" if apify else BASE_URL + "/v1/auth/login"
        payload = "{\"public_key\":\""+self.api_key+"\",\"private_key\":\""+self.private_key+"\"}"
        headers = {
            'Content-Type': 'application/json',
            'type': 'sdk-jwt',
            'Accept': 'application/json'
        }

        if (apify):
            text = "{public}:{private}".format(
                    public=self.api_key,
                    private=self.private_key
                )
            encode = base64.b64encode(text.encode("utf-8"))
            token = str(encode, "utf-8")
            headers["Authorization"] = "Basic {token}".format(token=token)
            payload = ""
        response = requests.request("POST", url, headers=headers, data = payload)
        

        if not response.text or response.status_code != 200:
            print(f"Error: Response from authentication endpoint")
            print(f"Status code: {response.status_code}")
            print(f"Response text: {response.text}")
            print(f"Response headers: {response.headers}")
            raise Exception(f"Authentication failed with status code: {response.status_code}")
        
        data=response.text.encode('utf8')
        try:
            json_data=json.loads(data)
        except json.JSONDecodeError as e:
            print(f"Error: Could not parse JSON response from authentication")
            print(f"Response text: {repr(response.text)}")
            print(f"Error: {e}")
            raise
        if apify:
            if 'token' not in json_data:
                print("Error: 'token' not found in authentication response:", json_data)
                raise Exception("Token not found in authentication response")
            bearer_token = json_data['token']
        else:
            if 'bearer_token' not in json_data:
                print("Error: 'bearer_token' not found in authentication response:", json_data)
                raise Exception("Bearer token not found in authentication response")
            bearer_token = json_data['bearer_token']
        return bearer_token
        
class NoRebuildAuthSession(Session):
    def rebuild_auth(self, prepared_request, response):
        """
        No code here means requests will always preserve the Authorization
        header when redirected.
        Be careful not to leak your credentials to untrusted hosts!
        """

class Client:

    BASE_URL = os.getenv("BASE_URL_SDK") if os.getenv("BASE_URL_SDK") else "https://eks-subscription-api-lumen-service.epayco.io"
    BASE_URL_SECURE = os.getenv("SECURE_URL_SDK") if os.getenv("SECURE_URL_SDK") else"https://eks-rest-pagos-service.epayco.io"
    ENTORNO = os.getenv("ENTORNO_SDK") if os.getenv("ENTORNO_SDK") else "/restpagos"
    BASE_URL_APIFY = os.getenv("BASE_URL_APIFY") if os.getenv("BASE_URL_APIFY") else "https://eks-apify-service.epayco.io"
    IV = "0000000000000000"
    LANGUAGE = "python"
    SWITCH= False

    def __init__(self):
        pass

    """
    Make request and return a Python object from the JSON response. If
    HTTP method is DELETE return True for 204 response, false otherwise.
    :param method: String with the HTTP method
    :param url: String with the EndPoint Api
    :param api_key: String with the API key
    :param data: Dictionary with query strings
    :param private_key: String with the Private key Api
    :param test: String TRUE O FALSE transaction in pruebas or production
    :param swich: Dictionary with data that will be sent
    :param lang: String languaje response errors
    :return: Native python object resulting of the JSON deserialization of the API response
    """


    def request(self,method='POST',url="",api_key="",data={}, private_key="",test="", switch="", lang="",cashdata="",dt="", apify=False, pse =False ):
        auth = Auth(api_key, private_key)
        authentication = auth.make(self.BASE_URL,self.BASE_URL_APIFY,apify)
        token_bearer = 'Bearer ' +authentication
        util = Util()
        if(hasattr(data, "__len__")):
            if(apify):
                data = util.setKeys_apify(data)
            elif(switch):
                data = util.setKeys(data)

        self.SWITCH=switch  
        self.APIFY=apify
        headers = {
            'Content-Type': 'application/json',
            'type': 'sdk-jwt',
            'lang': 'PYTHON',
            'Authorization': token_bearer
        }

        try:
            if (method == "GET"):
                if(apify):
                   # response=requests.get(self.build_url(url), data={},headers=headers)
                   url_bank = f"{self.build_url(url)}?test={str(test).lower()}"
                   response = requests.request("GET", url_bank, headers=headers, data=data)
                elif (switch):
                  if (switch):
                    if test == True or test == "true":
                        test = "TRUE"
                    else:
                        test = "FALSE"

                    aes = AESCipher(private_key,self.IV)
                    enpruebas=aes.encrypt(test)
                    addData = {
                        'public_key': api_key,
                        'i': base64.b64encode(self.IV.encode('ascii')),
                        'lenguaje': self.LANGUAGE,
                        'enpruebas': enpruebas,
                    }
                    url_params = addData
                    url_params.update(data)
                    response=requests.get(self.build_url(url), data={},params=url_params,auth=(api_key, ""),headers=headers)

                else:
                    url_params=data
                    payload = {}
                   # session = NoRebuildAuthSession()
                    response = requests.get(self.build_url(url), headers=headers, data = payload, params=url_params)

            elif (method == "POST"):
                if pse == True: 
                  
                    aes = AESCipher(private_key, self.IV)

                    data["extras_epayco"] = {"extra5": "P43"}  

                    if switch:
                     
                        if isinstance(test, bool) or (isinstance(test, str) and test.lower() in ["true", "false"]):
                            test = "TRUE" if str(test).lower() == "true" else "FALSE"

                        data_to_encrypt = data.copy()
                        extras_epayco = data_to_encrypt.pop("extras_epayco", None)
                  

                        encryptData = aes.encryptArray(data_to_encrypt)

                        if factura:
                            encryptData["factura"] = factura
                        if extras_epayco:
                            encryptData["extras_epayco"] = {"extra5": aes.encrypt(extras_epayco["extra5"]).decode('utf-8')}

                        addData = {
                            'public_key': api_key,
                            'i': base64.b64encode(self.IV.encode('ascii')).decode('utf-8'),
                            'enpruebas': aes.encrypt(test).decode('utf-8'),
                            'lenguaje': self.LANGUAGE,
                            'p': ''
                        }

                        enddata = {**encryptData, **addData}
                        payload = json.dumps(enddata)
                        response = requests.post(self.build_url(url), data=payload, headers=headers)
                        return response.json()
                else:
                 for key, value in data.items():
                    if isinstance(value, bytes):
                        data[key] = value.decode('utf-8')
               
                if "extras_epayco" not in data or not isinstance(data["extras_epayco"], dict):
                    data["extras_epayco"] = {"extra5": "P43"}
                else:
                    data["extras_epayco"]["extra5"] = "P43"

                if switch:
                    if test is True or str(test).lower() == "true":
                        test = "TRUE"
                    else:
                        test = "FALSE"
                    addData = {
                        'public_key': api_key,
                        'enpruebas': test,
                        'lenguaje': self.LANGUAGE,
                        'p': ''
                    }
                    enddata = {}
                    enddata.update(data)
                    enddata.update(addData)
                    payload = json.dumps(enddata)
                    response = requests.post(self.build_url(url), data=payload, headers=headers)
                    return response.json()
                else:
                   if dt:
                        payload = json.dumps(data)
                        response = requests.request("POST", self.build_url(url), headers=headers, data=payload)
                   else:
                        enddata = {}
                        data.update({'test': test})
                        enddata.update(data)
                        payload = json.dumps(enddata)
                        response = requests.request("POST", self.build_url(url), headers=headers, data=payload)

                   
            elif (method == "PATCH"):
                response = requests.request(
                    method,
                    self.build_url(url),
                    data=json.dumps(data),
                    auth=(token_bearer, ""),
                    headers=headers
                )
            elif (method == "DELETE"):
                response = requests.request(
                    method,
                    self.build_url(url),
                    data=json.dumps(data),
                    auth=(token_bearer, ""),
                    headers=headers
                )
        except Exception as e:
            print(f"Se ha producido un error: {e}")
            #traceback.print_exc()
            raise  errors.ErrorException(lang, 101)
      

        if (response.status_code >= 200 and response.status_code <= 206):
            if (method == "DELETE"):
                return response.status_code == 204 or response.status_code == 200
            return response.json()
    
        if (response.status_code >= 400 or response.status_code <= 500):
            try:
                if (response.status_code == 400):
                    raise errors.ErrorException(lang, 103)
                

                if (response.status_code == 401):
                    raise errors.ErrorException(lang, 104)

                if (response.status_code == 404):
                    raise errors.ErrorException(lang, 105)

                if (response.status_code == 403):
                    raise errors.ErrorException(lang, 106)

                if (response.status_code == 405):
                    raise errors.ErrorException(lang, 107)
                
            except errors.ErrorException as e:
                try:
                    response_json = response.json()
                except ValueError:
                    response_json = {}

                response_json = json.dumps(response_json) 
                errorExcepcion = json.dumps({
                    "status": False,
                    "message": str(e),
                    "data": response_json,
                    'errors': {'http_code': response.status_code}
                })

                response_final = json.loads(errorExcepcion)
                return response_final
            
    def build_url(self,endpoint):
            """
            Build complete URL from API endpoint
            :param endpoint: String with the endpoint, ex: /v1/charges/
            :return: String with complete URL, ex: https://api.secure.payco.co/v1/charges/
            """
            if(self.APIFY):
                return "{base_url}/{endpoint}".format(
                    base_url=self.BASE_URL_APIFY,
                    endpoint=endpoint
                )
            elif(self.SWITCH):
                return "{base_url}{entorno}{endpoint}".format(
                    base_url=self.BASE_URL_SECURE,
                    entorno=self.ENTORNO,
                    endpoint=endpoint
                )
            else:
                return "{base_url}/{endpoint}".format(
                    base_url=self.BASE_URL,
                    endpoint=endpoint   
                )
